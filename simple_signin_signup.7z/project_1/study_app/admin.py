from django.contrib import admin

from study_app.models import UserData

admin.site.register(UserData)