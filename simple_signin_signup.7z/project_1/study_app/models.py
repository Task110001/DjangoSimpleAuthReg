from django.db import models


class UserData(models.Model):
    username = models.CharField(max_length=30, verbose_name='Username', unique=True)
    email= models.EmailField(max_length=50, verbose_name='email', unique=True)
    password = models.CharField(max_length=255, verbose_name='Password')
    
    
    def __str__(self):
        return self.username
    
    
    class Meta:
        verbose_name = 'Users'
        verbose_name_plural = 'Users'
        ordering = ['id']